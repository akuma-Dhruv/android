package com.dhruv.animation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import java.nio.InvalidMarkException;

public class MainActivity extends AppCompatActivity {

    boolean ontap=true;
    public void bartTap(View view)
    {
        Log.i("bart","tap");
        ImageView bart = findViewById(R.id.bartImage);
        ImageView bulb = findViewById((R.id.bulbImage));
        if(ontap) {
            ontap = false;
            bart.animate().alpha(0).setDuration(1500);
            bulb.animate().alpha(1).setDuration(1500);
        }
        else {
            ontap = true;
            bart.animate().alpha(1).setDuration(1500);
            bulb.animate().alpha(0).setDuration(1500);
        }

        }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
