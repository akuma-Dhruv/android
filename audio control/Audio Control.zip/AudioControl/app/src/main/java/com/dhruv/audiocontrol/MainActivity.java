package com.dhruv.audiocontrol;

import androidx.appcompat.app.AppCompatActivity;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    MediaPlayer sound;
    AudioManager audioManager;
    public void play (View view)
    {
        Button play = (Button)findViewById(R.id.playButton);


        sound.start();

    }
    public void pause (View view)
    {
        Button pause = (Button)findViewById(R.id.pausebutton);

        
        sound.pause();
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        +





        final SeekBar scrubSeekBar;
        scrubSeekBar= (SeekBar) findViewById(R.id.scrubSeekBar);
        scrubSeekBar.setMax(sound.getDuration());
        scrubSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            sound.seekTo(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                sound.pause();

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                sound.start();

            }
        });

        new Timer().scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                scrubSeekBar.setProgress(sound.getCurrentPosition());
            }
        },0,1000);



    }
}
