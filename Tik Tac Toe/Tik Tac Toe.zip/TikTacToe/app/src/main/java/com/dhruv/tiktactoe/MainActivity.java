package com.dhruv.tiktactoe;

import androidx.appcompat.app.AppCompatActivity;
import androidx.gridlayout.widget.GridLayout;
import android.content.Context;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
        boolean activity = true;
        int [] box ={5,5,5,5,5,5,5,5,5,5};
        int [][] winCase = {{1,2,3},{4,5,6},{7,8,9},{1,4,7},{2,5,8},{3,6,9},{1,5,9},{3,5,7}};
        String winner;
        int activePlayer = 0;


    public void onTap(View view) {

        ImageView yellow = (ImageView) view;
        int tagVal = Integer.parseInt(yellow.getTag().toString());
        Button playAgainButton  = (Button)findViewById(R.id.again);
        TextView winnerText =  (TextView) findViewById(R.id.result);

        if (box[tagVal] == 5&& activity) {
            if (activePlayer == 1) {
                activePlayer = 0;
                yellow.setTranslationY(-1000);
                yellow.setImageResource(R.drawable.close);
                yellow.animate().translationYBy(1000);
                box[tagVal]++;
            }
                else {
                activePlayer = 1;
                yellow.setTranslationY(-1000);
                yellow.setImageResource(R.drawable.circle);
                yellow.animate().translationYBy(1000);
                box[tagVal]--;
                }


            for(int[] winCases :winCase) {
                if (box[winCases[0]] == box[winCases[1]]&&box[winCases[1]] == box[winCases[2]] && box[winCases[2]]!=5) {
                    if (activePlayer == 1)
                        winner="Yellow Won!";
                    else
                        winner="Red Won!";
                        activity = false;

                    winnerText.setText(winner);
                    playAgainButton.setText("Play Again");
                    winnerText.setVisibility(view.VISIBLE);
                    playAgainButton.setVisibility(view.VISIBLE);


                }
            }

        }
            else {
            int tCase =0;
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            v.vibrate(400);
            for(int e=1;e<10;e++)
            {
                if(box[e]!=5)
                {
                    tCase++;
                }
                if (tCase == 9)
                { activity =false;
                    winnerText.setText("It's a Draw! ");
                    playAgainButton.setText("Try Again");
                    winnerText.setVisibility(view.VISIBLE);
                    playAgainButton.setVisibility(view.VISIBLE);

                }
            }

        }


        }


        public void playAgain (View view){
                Button playAgainButton  = (Button)findViewById(R.id.again);
                TextView winnerText =  (TextView) findViewById(R.id.result);

               winnerText.setVisibility(view.INVISIBLE);
                playAgainButton.setVisibility(view.INVISIBLE);

            GridLayout gridLayout;
            gridLayout = (GridLayout) findViewById(R.id.gridLayout1);

            for(int i=0; i<9; i++) {

                ImageView counter = (ImageView) gridLayout.getChildAt(i);

                counter.setImageDrawable(null);
            }

            for(int i=0;i<box.length;i++)
            {
                box[i]=5;
            }

                activePlayer =0;
                activity=true;
            }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MediaPlayer mediaPlayer;
        mediaPlayer = MediaPlayer.create(this,R.raw.sony);

        mediaPlayer.start();
        mediaPlayer.setLooping(true);
    }
}
