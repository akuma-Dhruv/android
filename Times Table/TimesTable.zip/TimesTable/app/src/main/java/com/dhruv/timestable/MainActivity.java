package com.dhruv.timestable;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
     ListView mylist ;
    Integer famList[] ={1,2,3,4,5,6,7,8,9,10};
    Integer fat[] ={1,2,3,4,5,6,7,8,9,10};
        public void change (int progress)
        {
            for(int i=0;i<10;i++)
            {
                fat[i]=famList[i]*progress;

            }
            ArrayAdapter<Integer> arrayAdapter=  new ArrayAdapter<Integer>(this,android.R.layout.simple_list_item_1,fat);
            mylist.setAdapter(arrayAdapter);


        }



    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


       // final ArrayAdapter<Integer> arrayAdapter=  new ArrayAdapter<Integer>(this,android.R.layout.simple_list_item_1,famList);
        mylist = (ListView)findViewById(R.id.list);
        SeekBar seekBar=(SeekBar)findViewById(R.id.seek);
        seekBar.setMax(25);
        seekBar.setProgress(5);
        change(5);
        seekBar.setMin(1);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                change(progress);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });




    }
}
