package com.dhruv.tapquick;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Random;


public class MainActivity extends AppCompatActivity {




//////////////////////GLOBAL DECLARATION********************

int answerSet[]={1,1,1,1};
int correctAnswerPos;
int score=0;
int totalques=0;
long time;
    TextView resultText;
    TextView sumText;
    TextView scoreText;
    TextView timeText;
    TextView mainText;
    Button submitButton1 ;
    Button submitButton2 ;
    Button submitButton3 ;
    Button submitButton4 ;
    Button playAgain;



  ////////*********************FUNCTIONS****************************/////////////////////////////////////////

    public void timer() {
        playAgain=findViewById(R.id.playAgainButton);
        new CountDownTimer(30100, 1000) {
            @Override
            public void onTick(long m) {
                timeText.setText(String.valueOf(m / 1000));
                time = m;
            }

            @Override
            public void onFinish() {
                resultText.setText("Done!");
                submitButton1.setEnabled(false);
                submitButton2.setEnabled(false);
                submitButton3.setEnabled(false);
                submitButton4.setEnabled(false);
                playAgain.setVisibility(View.VISIBLE);
            }
        }.start();


    }
    /////////*********************
    public void submit (View view) {


        if (Integer.toString(correctAnswerPos).equals(view.getTag().toString())) {
            score++;
            resultText.setText("Correct!!");


        } else {
            resultText.setText("Wrong!");
        }

        generate();

}

/////////////////////////////////////////////////////

    public void start( View view)

    {ConstraintLayout gamelayout=findViewById(R.id.gameView);
        Button startButton =(Button)findViewById(R.id.startButton);
        startButton.setVisibility(View.INVISIBLE);
        startButton.setEnabled(false);
        mainText=findViewById(R.id.mainText);
        mainText.setVisibility(View.INVISIBLE);
       gamelayout.setVisibility(View.VISIBLE);
        generate();
    }

//////////////////////////////////////////////////////////////////

    public void generate()

    {
        if (totalques==0)
        {timer();}
    int n=0;
    totalques++;
    scoreText= findViewById(R.id.scoreView);
    timeText= findViewById(R.id.timeView);
    scoreText.setText(Integer.toString(score)+":"+Integer.toString(totalques));
     sumText = findViewById(R.id.problemView);
    Random rand = new Random();
    int a = rand.nextInt(24)+1;
    int b = rand.nextInt(24)+1;
    sumText.setText(String.valueOf(a)+"+"+String.valueOf(b)+"= ");
    for(int i=0;i<4;i++)
        {
        n=rand.nextInt(60);
        answerSet[i]=n;

        }
    correctAnswerPos = rand.nextInt(4);
        n=0;
    while (n<4)
        {
        if(answerSet[n]==a+b)
            {
                answerSet[n]+=5;

            }n++;
        }
    answerSet[correctAnswerPos]=a+b;
    resultText = findViewById(R.id.resultText);
    submitButton1 = findViewById(R.id.button1);
    submitButton2 = findViewById(R.id.button2);
    submitButton3 = findViewById(R.id.button3);
    submitButton4 = findViewById(R.id.button4);
    submitButton1.setText(Integer.toString(answerSet[0]));
    submitButton2.setText(Integer.toString(answerSet[1]));
    submitButton3.setText(Integer.toString(answerSet[2]));
    submitButton4.setText(Integer.toString(answerSet[3]));

    }
//**************************************************************************************************
    public void playAgain (View view)
    {
     score=0;
     totalques=0;
     resultText.setText("");
        submitButton1.setEnabled(true);
        submitButton2.setEnabled(true);
        submitButton3.setEnabled(true);
        submitButton4.setEnabled(true);
        playAgain.setVisibility(View.INVISIBLE);
     generate();

      }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



    }
}
