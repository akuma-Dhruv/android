package com.dhruv.login;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    public void LoginButton (View view)
    {

        EditText nameEditText =findViewById(R.id.nameEditText);
        Log.i("loginid",nameEditText.getText().toString());
        EditText password = findViewById(R.id.password);
        Log.i("pass",password.getText().toString());
        Log.i("loginB","pressed!");
        Toast.makeText(this, "Hello "+nameEditText.getText().toString(), Toast.LENGTH_SHORT).show();



    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
