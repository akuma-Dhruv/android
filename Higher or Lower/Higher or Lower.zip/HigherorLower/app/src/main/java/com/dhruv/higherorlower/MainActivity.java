package com.dhruv.higherorlower;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
  public void  generateRandom()
  {
      Random rand = new Random();
      n = rand.nextInt(20)+1;

  }
    int n;
    public void onTap (View view)
    {
        String message;

        EditText num = findViewById(R.id.numb);

        Log.i("ontap",num.getText().toString());
        String value = num.getText().toString();
        int inp = Integer.parseInt(value);




        if (inp>n)
        {
            message ="LOWER! ";
        }
        else if (inp<n)
        {
            message = "HIGHER! ";

        }
        else
        {
            message ="YOU GET IT!  Lets play again";
            generateRandom();
        }
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        generateRandom();

    }
}
