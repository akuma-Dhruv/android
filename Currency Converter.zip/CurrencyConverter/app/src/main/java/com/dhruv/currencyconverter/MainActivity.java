package com.dhruv.currencyconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public void ontap(View view)
    {
        Log.i("tap","tapped!");
        EditText editText = (EditText) findViewById(R.id.editText);
        String amountInRupees = editText.getText().toString();
        Double amountInRupeesD = Double.parseDouble(amountInRupees);
        Double amountInDollarD = amountInRupeesD / 75;
        String amountIndollarS = String.format("%.2f",amountInDollarD);
        Toast.makeText(this, "₹"+amountInRupees + " = $"+ amountIndollarS, Toast.LENGTH_LONG).show();
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
