package com.dhruv.eggtimer;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
long count=30000;

    public void initialize () {




        SeekBar seekBar = (SeekBar) findViewById(R.id.seekBar);
        seekBar.setMax(600);
        seekBar.setProgress(30);
        final TextView time = findViewById(R.id.timeView);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
            {int min = progress/60;
                int sec = progress-(min*60);
                count=progress*1000;
                time.setText(Integer.toString(min)+":"+String.valueOf(sec));

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });







    }

        public void startProcess (View view)
    {final TextView time = findViewById(R.id.timeView);
        final Button button = (Button) findViewById(R.id.goButton);
        final MediaPlayer sound;
        sound = MediaPlayer.create(this,R.raw.awm_sound);

            new CountDownTimer(count, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                   long min = millisUntilFinished/60000;
                    long sec= (millisUntilFinished/1000) - (min*60);

                    time.setText(Long.toString(min)+":"+ String.valueOf(sec));
                    button.setEnabled(false);

                }

                @Override
                public void onFinish() {
                    button.setEnabled(true);
                    sound.start();

                }
            }.start();


    }








    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize();
    }
}
